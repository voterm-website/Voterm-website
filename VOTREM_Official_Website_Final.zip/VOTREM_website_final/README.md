# VOTREM Official Website

Voice on the Rock Evangelical Mission (VOTREM)

Vision: **Standing Upon the Rock, Proclaiming His Voice.**

## Design direction
- Mature, dignified, institutional evangelical identity
- Deep navy #081D3A, gold #DAAF37, ivory #F8F7F2
- Minimal animation and no commercial-looking clutter
- Mobile responsive
- No external paid libraries or image dependencies

## Pages
Home, About, Beliefs, Ministries, Teachings, Programmes, Library, Membership, Give, Prayer, Leadership, Governance, Contact.

## Important before publishing
1. Replace placeholder Constitution/Statement of Faith links with the approved documents.
2. Confirm all leadership offices and department names against the Constitution.
3. Connect prayer, membership and contact forms to an approved secure form service before collecting personal information.
4. Add only official giving/payment details.
5. Add official social-media links after confirming the accounts.

## Free hosting
This is a static site designed for GitHub Pages. The existing `voiceontherock.org` domain can be connected to the GitHub Pages site through DNS.
