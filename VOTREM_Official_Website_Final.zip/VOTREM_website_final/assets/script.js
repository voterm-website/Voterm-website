const menu=document.getElementById('menu'),nav=document.getElementById('nav');
if(menu&&nav){menu.addEventListener('click',()=>{nav.classList.toggle('open');menu.setAttribute('aria-expanded',nav.classList.contains('open'))})}
const back=document.querySelector('.backtop');
if(back){window.addEventListener('scroll',()=>back.classList.toggle('show',scrollY>500));back.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}))}
const year=document.querySelectorAll('[data-year]');year.forEach(x=>x.textContent=new Date().getFullYear());
